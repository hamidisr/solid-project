﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace UserManager
{
    public partial class UmForm : Form
    {
        private readonly IUserRepository _repository;
        private int? selectedUserId = null;

        public UmForm()
        {
            InitializeComponent();
            string connectionString = @"Data Source=.\SQLEXPRESS;AttachDbFilename=D:\Databases\Tamrin\um.mdf;Integrated Security=True;Connect Timeout=30;Encrypt=False;User Instance=True";
            _repository = new SqlUserRepository(connectionString);
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            LoadUsers();
        }

        private void LoadUsers()
        {
            comboBox1.Items.Clear();
            var users = _repository.GetAllUsers();
            foreach (var user in users)
            {
                comboBox1.Items.Add($"{user.Id} - {user.Name}");
            }
        }

        private void SearchUserClick(object sender, EventArgs e)
        {
            if (comboBox1.SelectedItem == null)
                return;

            selectedUserId = int.Parse(comboBox1.SelectedItem.ToString().Split('-')[0]);
            var user = _repository.GetUserById(selectedUserId.Value);

            if (user != null)
            {
                editUserName.Text = user.Name;
                editUserMobileNo.Text = user.MobileNo;
                editUserAddress.Text = user.Address;
            }
        }

        private void CreateUserClick(object sender, EventArgs e)
        {
            var user = new User
            {
                Name = newUserName.Text,
                MobileNo = newUserMobileNo.Text,
                Address = newUserAddress.Text
            };

            _repository.CreateUser(user);
            MessageBox.Show("User created.");
            ClearNewUserFields();
            LoadUsers();
        }

        private void EditUserClick(object sender, EventArgs e)
        {
            if (selectedUserId == null)
            {
                MessageBox.Show("Select a user first.");
                return;
            }

            var updatedUser = new User
            {
                Id = selectedUserId.Value,
                Name = editUserName.Text,
                MobileNo = editUserMobileNo.Text,
                Address = editUserAddress.Text
            };

            _repository.UpdateUser(updatedUser);
            MessageBox.Show("User updated.");
            ClearEditUserFields();
            LoadUsers();
        }

        private void DeleteUserClick(object sender, EventArgs e)
        {
            if (selectedUserId == null)
            {
                MessageBox.Show("Select a user first.");
                return;
            }

            _repository.DeleteUser(selectedUserId.Value);
            MessageBox.Show("User deleted.");
            ClearEditUserFields();
            LoadUsers();
        }
        private void ClearNewUserFields()
        {
            newUserName.Text = newUserMobileNo.Text = newUserAddress.Text = "";
        }

        private void ClearEditUserFields()
        {
            editUserName.Text = editUserMobileNo.Text = editUserAddress.Text = "";
            selectedUserId = null;
        }





    }
}
